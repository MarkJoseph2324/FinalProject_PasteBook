﻿namespace FinalProject_PasteBook
{
    public class Mapper
    {
        
    }
}