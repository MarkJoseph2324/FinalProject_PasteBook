﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PasteBook_FinalProject
{
    public class UserModel
    {
        public CountryModel CountryModel { get; set; }
        public RegistrationModel RegistrationModel { get; set; }
    }
}